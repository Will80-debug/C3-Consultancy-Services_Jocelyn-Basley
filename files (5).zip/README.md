# C3 Consultancy Services Website

Official website for **C3 Consultancy Services LLC**  
*Connection Is the Strategy*

## About
C3 Consultancy Services specializes in working with small grassroots organizations, nonprofits, and community-based groups through:
- Nonprofit Consulting
- Executive Coaching  
- Strategic Planning

**Location:** 74 Dr. Samuel McCree Way, Rochester, NY 14608  
**Website:** [c3consultancyservices.com](https://c3consultancyservices.com)

## Files
- `index.html` — Complete single-file website (all pages, images, and assets embedded)

## Deployment
This site is deployed via **GitHub Pages**.  
Live at: `https://yourusername.github.io/repository-name`

To update: upload a new `index.html` and GitHub Pages will republish automatically.

---
© 2025 C3 Consultancy Services LLC. All rights reserved.
